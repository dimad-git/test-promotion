import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'test-project';
  display: boolean = false;
  time_one: boolean = true;
  closeBtn: boolean = true;
   ngOnInit() {
  	this.progressBar();
  }

  progressBar(){
  	 var timeleft = 3;
	var downloadTimer = setInterval(function(){
  	var timer = 4 - timeleft;
  	timeleft -= 1;
  	if(timeleft <= 0){
  		    	this.closeBtn = !this.closeBtn;
    	this.time_one = !this.time_one;
    	clearInterval(downloadTimer);

    	console.log(this.time_one, this.closeBtn);
}
}, 1000);
  }

  closeMark(){
  	this.display= !this.display;
  	console.log("close");
  }
  
}
