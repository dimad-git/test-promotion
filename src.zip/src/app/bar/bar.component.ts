import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.scss']
})
export class BarComponent implements OnInit {
	  time: boolean = true;
  
  constructor() { }

  ngOnInit() {
  //	this.progressBar();
  }

  progressBar(){
  	 var timeleft = 3;
	var downloadTimer = setInterval(function(){
  	var timer = 4 - timeleft;
  	timeleft -= 1;

  	if(timeleft <= 0){
    	clearInterval(downloadTimer);
    	this.time = false;
    	console.log(this.time);
}
}, 1000);
  }

}
